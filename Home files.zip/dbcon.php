<?php

    $con = mysqli_connect("localhost","root","Harshi#2005","artgallery");
?>