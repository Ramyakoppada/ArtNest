<?php

include 'emailTesting.php'; 
    sendEmail('lalithya varma','22b01a05a3@svecw.edu.in','9989244077',TRUE);


?>